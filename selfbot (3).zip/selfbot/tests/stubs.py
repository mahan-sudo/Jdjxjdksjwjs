"""کتابخونه‌های بیرونی (aiogram, telethon, redis, ...) رو با نسخه‌ی ساختگیِ سبک جایگزین می‌کنه
تا منطق اتصال حساب بدون اینترنت و بدون تلگرام واقعی تست بشه."""
import sys
import types


def install():
    def mod(name, **attrs):
        m = types.ModuleType(name)
        m.__dict__.update(attrs)
        sys.modules[name] = m
        return m

    # ---------------- aiogram
    class TelegramAPIError(Exception):
        pass

    class TelegramBadRequest(TelegramAPIError):
        pass

    class Obj:
        def __init__(self, *a, **k):
            self.args = a
            self.__dict__.update(k)

    class Chat:
        def __init__(self, id):
            self.id = id

    class User:
        def __init__(self, id):
            self.id = id

    class Message:
        def __init__(self, message_id=0, chat=None, from_user=None, text=None, bot=None):
            self.message_id, self.chat, self.from_user, self.text, self._bot = message_id, chat, from_user, text, bot

        async def delete(self):
            if self._bot:
                await self._bot.delete_message(self.chat.id, self.message_id)

    class CallbackQuery:
        def __init__(self, from_user, message):
            self.from_user, self.message, self.answers = from_user, message, []

        async def answer(self, text=None, show_alert=False, **kw):
            self.answers.append((text, show_alert))

    class BufferedInputFile:
        def __init__(self, data, filename=None):
            self.data, self.filename = data, filename

    class CallbackData:
        def __init_subclass__(cls, prefix="", **kw):
            cls.__prefix__ = prefix

        def __init__(self, **kw):
            ann = {}
            for c in reversed(type(self).__mro__):
                ann.update(getattr(c, "__annotations__", {}))
            self._keys = list(ann)
            for k in ann:
                setattr(self, k, kw.get(k, getattr(type(self), k, "")))

        def pack(self):
            return f"{self.__prefix__}:" + ":".join(str(getattr(self, k)) for k in self._keys)

    mod("aiogram", Bot=Obj)
    mod("aiogram.exceptions", TelegramAPIError=TelegramAPIError, TelegramBadRequest=TelegramBadRequest)
    mod(
        "aiogram.types",
        Message=Message,
        CallbackQuery=CallbackQuery,
        BufferedInputFile=BufferedInputFile,
        InputMediaPhoto=Obj,
        CopyTextButton=Obj,
        InlineKeyboardButton=Obj,
        InlineKeyboardMarkup=Obj,
        KeyboardButton=Obj,
        ReplyKeyboardMarkup=Obj,
    )
    mod("aiogram.filters", )
    mod("aiogram.filters.callback_data", CallbackData=CallbackData)

    # ---------------- telethon
    class RPCError(Exception):
        def __init__(self, *a, seconds=0):
            super().__init__(*a)
            self.seconds = seconds

    def err(name):
        return type(name, (RPCError,), {})

    errors = {n: err(n) for n in [
        "FloodWaitError", "PasswordHashInvalidError", "PhoneCodeEmptyError", "PhoneCodeExpiredError",
        "PhoneCodeInvalidError", "PhoneNumberBannedError", "PhoneNumberFloodError", "PhoneNumberInvalidError",
        "SessionPasswordNeededError",
    ]}
    mod("telethon", TelegramClient=Obj)
    mod("telethon.errors", RPCError=RPCError, **errors)
    mod("telethon.sessions", StringSession=Obj)

    # ---------------- redis
    class RedisError(Exception):
        pass

    mod("redis")
    mod("redis.asyncio", Redis=Obj)
    mod("redis.exceptions", RedisError=RedisError)

    # ---------------- qrcode
    class _Img:
        def save(self, buf, format=None):
            buf.write(b"\x89PNG-fake")

    mod("qrcode", make=lambda url, box_size=8, border=2: _Img())

    # ---------------- pydantic
    def field_validator(*a, **k):
        return lambda f: f

    class BaseSettings:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    mod("pydantic", field_validator=field_validator)
    mod("pydantic_settings", BaseSettings=BaseSettings, SettingsConfigDict=lambda **k: k)

    # ---------------- ذخیره‌ی حساب (دیتابیس ساختگی)
    saved = []

    async def save_account(session, user_id, phone, session_string, vault, now):
        saved.append(dict(user_id=user_id, phone=phone, session=session_string))
        return True

    sys.modules.pop("app.services.accounts", None)
    mod("app.services.accounts", save_account=save_account, SAVED=saved)
    return saved
