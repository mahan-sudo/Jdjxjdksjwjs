"""تست منطق اتصال حساب (کد، رمز دومرحله‌ای، QR، تایم‌اوت، لغو، خطاها) با تلگرام ساختگی."""
import asyncio
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

import stubs  # noqa: E402

SAVED = stubs.install()

import app.login as L  # noqa: E402
from aiogram.exceptions import TelegramBadRequest  # noqa: E402
from aiogram.types import CallbackQuery, Message  # noqa: E402
from app.keyboards import LoginKey  # noqa: E402
from telethon.errors import (  # noqa: E402
    FloodWaitError,
    PhoneNumberInvalidError,
)

import telethon.errors as TE  # noqa: E402

CHAT = 500
UID = 7


# ------------------------------------------------------------ بدلی‌ها
class Obj:
    def __init__(self, **k):
        self.__dict__.update(k)


class FakeBot:
    def __init__(self):
        self.n = 1000
        self.msgs = {}
        self.deleted = []
        self.fail_edit_text = False
        self.fail_link_caption = False
        self.photos = 0

    def _add(self, kind, text, markup):
        self.n += 1
        self.msgs[self.n] = {"kind": kind, "text": text, "markup": markup}
        return Message(message_id=self.n, chat=Obj(id=CHAT), bot=self)

    async def send_message(self, chat_id, text, reply_markup=None, parse_mode=None, **kw):
        return self._add("text", text, reply_markup)

    async def send_photo(self, chat_id, photo, caption="", reply_markup=None, **kw):
        if self.fail_link_caption and "href" in caption:
            raise TelegramBadRequest("BUTTON/ENTITY invalid")
        self.photos += 1
        return self._add("photo", caption, reply_markup)

    async def edit_message_text(self, text, chat_id=None, message_id=None, reply_markup=None, **kw):
        if self.fail_edit_text or message_id not in self.msgs:
            raise TelegramBadRequest("Bad Request: message can't be edited")
        self.msgs[message_id].update(text=text, markup=reply_markup)

    async def edit_message_media(self, media, chat_id=None, message_id=None, reply_markup=None, **kw):
        if message_id not in self.msgs:
            raise TelegramBadRequest("gone")
        self.msgs[message_id]["text"] = media.caption

    async def delete_message(self, chat_id, message_id):
        self.msgs.pop(message_id, None)
        self.deleted.append(message_id)

    async def delete_messages(self, chat_id, ids):
        for i in ids:
            await self.delete_message(chat_id, i)

    def visible(self):
        return [m["text"] for m in self.msgs.values()]

    def menu_messages(self):
        return [m for m in self.msgs.values() if m["text"] == "🏠"]


class FakeRedis:
    def __init__(self):
        self.d = {}

    def pipeline(self):
        r = self

        class P:
            def __init__(self):
                self.ops = []

            def incr(self, k):
                self.ops.append(("i", k))

            def ttl(self, k):
                self.ops.append(("t", k))

            async def execute(self):
                out = []
                for op, k in self.ops:
                    if op == "i":
                        r.d[k] = r.d.get(k, 0) + 1
                        out.append(r.d[k])
                    else:
                        out.append(100)
                return out

        return P()

    async def expire(self, k, w):
        pass


class FakeDB:
    def begin(self):
        class C:
            async def __aenter__(s):
                return object()

            async def __aexit__(s, *a):
                return False

        return C()


# ---- تلگرام ساختگی (Telethon)
class SentCodeTypeApp:
    length = 5


class SentCodeTypeSms:
    length = 6


CFG = {}


def reset_cfg(**kw):
    CFG.clear()
    CFG.update(code="12345", need_2fa=False, password="pw", send_code_exc=None, sent_type=SentCodeTypeApp,
               qr_script=["ok"], qr_exc=None)
    CFG.update(kw)


class FakeQR:
    def __init__(self):
        self.url = "tg://login?token=T0"
        self.n = 0

    async def wait(self, timeout=None):
        step = CFG["qr_script"].pop(0) if CFG["qr_script"] else "timeout"
        await asyncio.sleep(0)
        if step == "timeout":
            raise asyncio.TimeoutError
        if step == "2fa":
            raise TE.SessionPasswordNeededError()
        if step == "boom":
            raise RuntimeError("boom")
        return Obj(phone="989123456789")

    async def recreate(self):
        self.n += 1
        self.url = f"tg://login?token=T{self.n}"


class FakeClient:
    instances = []

    def __init__(self, *a, **k):
        self.session = Obj(save=lambda: "SESSION-STRING")
        self.disconnected = False
        FakeClient.instances.append(self)

    async def connect(self):
        pass

    async def disconnect(self):
        self.disconnected = True

    async def send_code_request(self, phone):
        if CFG["send_code_exc"]:
            raise CFG["send_code_exc"]
        return Obj(type=CFG["sent_type"](), phone_code_hash="HASH", next_type=None)

    async def sign_in(self, phone=None, code=None, password=None, phone_code_hash=None):
        if password is not None:
            if password == CFG["password"]:
                return Obj(phone="989123456789")
            raise TE.PasswordHashInvalidError()
        if code != CFG["code"]:
            raise TE.PhoneCodeInvalidError()
        if CFG["need_2fa"]:
            raise TE.SessionPasswordNeededError()
        return Obj(phone="989123456789")

    async def qr_login(self):
        if CFG["qr_exc"]:
            raise CFG["qr_exc"]
        return FakeQR()


L.TelegramClient = FakeClient


def make():
    reset_cfg()
    SAVED.clear()
    FakeClient.instances.clear()
    bot = FakeBot()
    settings = Obj(telegram_api_id=1, telegram_api_hash="h", admin_id_set={1})
    mgr = L.LoginManager(bot, FakeDB(), FakeRedis(), settings, None)
    return bot, mgr


def user_msg(bot, text="", uid=UID):
    bot.n += 1
    return Message(message_id=bot.n, chat=Obj(id=CHAT), from_user=Obj(id=uid), text=text, bot=bot)


def panel_cb(bot, mgr, uid=UID):
    ctx = mgr.get(uid)
    return CallbackQuery(Obj(id=uid), Message(message_id=ctx.panel_msg_id, chat=Obj(id=CHAT)))


async def press(bot, mgr, act, d="", uid=UID):
    cb = panel_cb(bot, mgr, uid)
    await mgr.press(cb, LoginKey(act=act, d=d))
    return cb


async def type_code(bot, mgr, code):
    for ch in code:
        await press(bot, mgr, "d", ch)


# ------------------------------------------------------------ تست‌ها
async def t_happy_path():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    assert mgr.get(UID).stage == "phone"
    await mgr.submit_phone(user_msg(bot, "+989123456789"), "+989123456789")
    ctx = mgr.get(UID)
    assert ctx.stage == "code", ctx.stage
    assert ctx.code_len == 5
    assert any("ورود کد تلگرام" in t for t in bot.visible())
    # ناقص → هشدار
    await type_code(bot, mgr, "123")
    cb = await press(bot, mgr, "ok")
    assert cb.answers and cb.answers[-1][1] is True
    # backspace و پاک
    await press(bot, mgr, "b")
    assert len(mgr.get(UID).digits) == 2
    await press(bot, mgr, "c")
    assert mgr.get(UID).digits == []
    await type_code(bot, mgr, "12345")
    await press(bot, mgr, "ok")
    assert mgr.get(UID) is None
    assert SAVED == [dict(user_id=UID, phone="+989123456789", session="SESSION-STRING")], SAVED
    vis = bot.visible()
    assert vis == ["<b>سلف فعال شد.</b>"] or vis == [L.T.LOGIN_DONE], vis
    assert FakeClient.instances[0].disconnected


async def t_wrong_code_then_ok():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    await type_code(bot, mgr, "99999")
    cb = await press(bot, mgr, "ok")
    assert cb.answers[-1][0] == L.T.CODE_WRONG
    assert mgr.get(UID).digits == [] and mgr.get(UID).stage == "code"
    await type_code(bot, mgr, "12345")
    await press(bot, mgr, "ok")
    assert mgr.get(UID) is None and len(SAVED) == 1


async def t_too_many_wrong_codes():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    for _ in range(L.MAX_WRONG_CODES):
        await type_code(bot, mgr, "00000")
        await press(bot, mgr, "ok")
    assert mgr.get(UID) is None and not SAVED
    assert any("چند بار کد اشتباه" in t for t in bot.visible())


async def t_two_factor():
    bot, mgr = make()
    reset_cfg(need_2fa=True)
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    await type_code(bot, mgr, "12345")
    await press(bot, mgr, "ok")
    assert mgr.get(UID).stage == "password"
    # رمز اشتباه
    m = user_msg(bot, "bad")
    await mgr.submit_password(m)
    assert m.message_id in bot.deleted
    assert mgr.get(UID).stage == "password"
    assert any("رمز اشتباه" in t for t in bot.visible())
    # رمز درست
    m2 = user_msg(bot, "pw")
    await mgr.submit_password(m2)
    assert m2.message_id in bot.deleted
    assert mgr.get(UID) is None and len(SAVED) == 1


async def t_two_factor_too_many():
    bot, mgr = make()
    reset_cfg(need_2fa=True)
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    await type_code(bot, mgr, "12345")
    await press(bot, mgr, "ok")
    for _ in range(L.MAX_WRONG_PASSWORDS):
        await mgr.submit_password(user_msg(bot, "bad"))
    assert mgr.get(UID) is None and not SAVED


async def t_timeout():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    ctx = mgr.get(UID)
    ctx.idle = 1
    await asyncio.sleep(1.5)
    assert mgr.get(UID) is None
    vis = bot.visible()
    assert vis == [L.T.LOGIN_TIMEOUT], vis
    assert len(bot.menu_messages()) == 0  # پیام موقتِ منو پاک شده


async def t_activity_extends_timeout():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    ctx = mgr.get(UID)
    ctx.idle = 1
    for _ in range(3):
        await asyncio.sleep(0.6)
        await press(bot, mgr, "d", "1")
    assert mgr.get(UID) is not None  # با فعالیت، منقضی نشده
    await asyncio.sleep(1.4)
    assert mgr.get(UID) is None


async def t_cancel():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    await press(bot, mgr, "x")
    assert mgr.get(UID) is None
    assert bot.visible() == [], bot.visible()
    assert FakeClient.instances[0].disconnected


async def t_edit_failure_fallback():
    bot, mgr = make()
    bot.fail_edit_text = True
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    ctx = mgr.get(UID)
    assert ctx and ctx.stage == "code"
    vis = bot.visible()
    assert len(vis) == 1 and "ورود کد تلگرام" in vis[0], vis  # پیام جدید فرستاده شد و قدیمی پاک
    await type_code(bot, mgr, "12345")
    await press(bot, mgr, "ok")
    assert len(SAVED) == 1


async def t_invalid_phone_restarts():
    bot, mgr = make()
    reset_cfg(send_code_exc=PhoneNumberInvalidError())
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+98000")
    ctx = mgr.get(UID)
    assert ctx and ctx.stage == "phone"
    assert any(L.T.NOTE_BAD_PHONE in t for t in bot.visible())


async def t_flood_wait():
    bot, mgr = make()
    reset_cfg(send_code_exc=FloodWaitError(seconds=3000))
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    assert mgr.get(UID) is None
    assert any("حدود 50 دقیقه" in t for t in bot.visible()), bot.visible()


async def t_unexpected_error_reports_admin():
    bot, mgr = make()
    reset_cfg(send_code_exc=RuntimeError("weird"))
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    assert mgr.get(UID) is None
    assert any("RuntimeError" in t for t in bot.visible())  # گزارش برای ادمین
    assert any(L.T.LOGIN_ERROR in t for t in bot.visible())


async def t_rate_limit():
    bot, mgr = make()
    for _ in range(5):
        await mgr.start(CHAT, UID)
        await mgr.submit_phone(user_msg(bot), "+989123456789")
        await mgr.cancel(Obj(from_user=Obj(id=UID), answer=lambda *a, **k: asyncio.sleep(0)))
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    assert mgr.get(UID) is None
    assert any(L.T.LOGIN_RATE in t for t in bot.visible())


async def t_restart_replaces_old_flow():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.start(CHAT, UID, note="x")
    assert len([t for t in bot.visible() if "اتصال سلف به حساب" in t]) == 1


async def t_qr_happy_path():
    bot, mgr = make()
    reset_cfg(qr_script=["timeout", "timeout", "ok"])
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot, "🔳ورود بدون کد QR"))
    ctx = mgr.get(UID)
    assert ctx.stage == "qr" and bot.photos == 1
    await asyncio.wait_for(ctx.qr_task, 5)
    assert mgr.get(UID) is None
    assert SAVED and SAVED[0]["phone"] == "+989123456789", SAVED
    assert bot.visible() == [L.T.LOGIN_DONE], bot.visible()


async def t_qr_refreshes_token():
    bot, mgr = make()
    reset_cfg(qr_script=["timeout", "timeout", "ok"])
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot))
    ctx = mgr.get(UID)
    assert ctx.qr.url == "tg://login?token=T0"
    await asyncio.wait_for(ctx.qr_task, 5)
    assert ctx.qr.n == 2  # دو بار QR تازه ساخته شد


async def t_qr_link_fallback():
    bot, mgr = make()
    bot.fail_link_caption = True
    reset_cfg(qr_script=["ok"])
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot))
    ctx = mgr.get(UID) or None
    # حتی اگه لینک رد بشه، QR بدون لینک فرستاده می‌شه و ورود کامل می‌شه
    await asyncio.sleep(0.2)
    assert bot.photos == 1 and SAVED, (bot.photos, SAVED)


async def t_qr_two_factor():
    bot, mgr = make()
    reset_cfg(qr_script=["2fa"])
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot))
    ctx = mgr.get(UID)
    await asyncio.wait_for(ctx.qr_task, 5)
    assert mgr.get(UID).stage == "password"
    assert not any(m["kind"] == "photo" for m in bot.msgs.values())  # QR پاک شد
    await mgr.submit_password(user_msg(bot, "pw"))
    assert mgr.get(UID) is None and len(SAVED) == 1


async def t_qr_cancel():
    bot, mgr = make()
    reset_cfg(qr_script=["timeout"] * 50)
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot))
    await press(bot, mgr, "x")
    assert mgr.get(UID) is None and bot.visible() == []


async def t_qr_login_error():
    bot, mgr = make()
    reset_cfg(qr_exc=RuntimeError("nope"))
    await mgr.start(CHAT, UID)
    await mgr.start_qr(user_msg(bot))
    assert mgr.get(UID) is None
    assert any(L.T.LOGIN_ERROR in t for t in bot.visible())


async def t_stale_buttons_ignored():
    bot, mgr = make()
    await mgr.start(CHAT, UID)
    await mgr.submit_phone(user_msg(bot), "+989123456789")
    ctx = mgr.get(UID)
    stale = CallbackQuery(Obj(id=UID), Message(message_id=ctx.panel_msg_id + 99, chat=Obj(id=CHAT)))
    await mgr.press(stale, LoginKey(act="d", d="1"))
    assert stale.answers and mgr.get(UID).digits == []
    other = CallbackQuery(Obj(id=999), Message(message_id=ctx.panel_msg_id, chat=Obj(id=CHAT)))
    await mgr.press(other, LoginKey(act="ok"))  # کاربر دیگه
    assert other.answers and mgr.get(UID) is not None


async def t_users_are_isolated():
    bot, mgr = make()
    await mgr.start(CHAT, 1)
    await mgr.start(CHAT, 2)
    await mgr.submit_phone(user_msg(bot, uid=1), "+989111111111")
    await mgr.submit_phone(user_msg(bot, uid=2), "+989222222222")
    await type_code(bot, mgr, "12345") if False else None
    for uid in (1, 2):
        for ch in "12345":
            await press(bot, mgr, "d", ch, uid=uid)
        await press(bot, mgr, "ok", uid=uid)
    assert sorted(s["phone"] for s in SAVED) == ["+989111111111", "+989222222222"]


async def main():
    tests = [v for k, v in globals().items() if k.startswith("t_")]
    failed = 0
    for t in tests:
        try:
            await t()
            print("PASS", t.__name__)
        except Exception as e:  # noqa: BLE001
            failed += 1
            import traceback

            print("FAIL", t.__name__, "->", repr(e))
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    asyncio.run(main())
