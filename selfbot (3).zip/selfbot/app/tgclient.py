"""ساخت یکدست کلاینت تلگرام (Telethon) برای همه‌جا: ورود، موتور سلف و بررسی سلامت.
اینجا می‌شه مسیر اتصال (پروکسی) رو هم تعیین کرد؛ مثلاً برای اینکه تلگرام ورود رو از ارمنستان یا هلند ببینه."""
from __future__ import annotations

from urllib.parse import unquote, urlparse

from telethon import TelegramClient
from telethon.sessions import StringSession


def parse_proxy(url: str):
    """socks5://user:pass@host:port  ->  تاپلِ مورد نیاز Telethon. خالی یعنی بدون پروکسی."""
    url = (url or "").strip()
    if not url:
        return None
    u = urlparse(url)
    if u.scheme not in ("socks5", "socks4", "http") or not u.hostname or not u.port:
        raise ValueError("TELEGRAM_PROXY باید مثل socks5://user:pass@host:port باشه")
    return (
        u.scheme,
        u.hostname,
        u.port,
        True,
        unquote(u.username) if u.username else None,
        unquote(u.password) if u.password else None,
    )


def make_client(settings, session_string: str = "", **extra) -> TelegramClient:
    kwargs = dict(device_model="Self Assistant", system_version="Server", app_version="1.0")
    proxy = parse_proxy(getattr(settings, "telegram_proxy", ""))
    if proxy:
        kwargs["proxy"] = proxy
    kwargs.update(extra)
    return TelegramClient(
        StringSession(session_string), settings.telegram_api_id, settings.telegram_api_hash, **kwargs
    )
